import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const evaluations = pgTable("evaluations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  algorithmName: text("algorithm_name").notNull(),
  evaluatorName: text("evaluator_name").notNull(),
  industry: text("industry"), // Industry type for compliance
  complianceFrameworks: jsonb("compliance_frameworks").default([]), // Array of selected frameworks
  responses: jsonb("responses").notNull(), // Array of boolean responses
  complianceResponses: jsonb("compliance_responses").default({}), // Object with framework-specific responses
  totalScore: integer("total_score").notNull(),
  complianceScore: integer("compliance_score").default(0), // Additional compliance score
  riskCategory: text("risk_category").notNull(),
  categoryScores: jsonb("category_scores").notNull(), // Object with scores per category
  complianceBreakdown: jsonb("compliance_breakdown").default({}), // Framework-specific scores
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertEvaluationSchema = createInsertSchema(evaluations).omit({
  id: true,
  createdAt: true,
});

export type InsertEvaluation = z.infer<typeof insertEvaluationSchema>;
export type Evaluation = typeof evaluations.$inferSelect;

// Question structure for frontend
export const questionSchema = z.object({
  id: z.number(),
  category: z.string(),
  categoryIndex: z.number(),
  question: z.string(),
  description: z.string(),
  recommendation: z.string(), // Specific recommendation for "No" answers
});

export type Question = z.infer<typeof questionSchema>;

// Response structure
export const evaluationResponseSchema = z.object({
  algorithmName: z.string().min(1, "Algorithm name is required"),
  evaluatorName: z.string().min(1, "Evaluator name is required"),
  industry: z.string().optional(),
  complianceFrameworks: z.array(z.string()).default([]),
  responses: z.array(z.boolean()).length(20, "All 20 questions must be answered"),
  complianceResponses: z.record(z.array(z.boolean())).default({}),
});

export type EvaluationResponse = z.infer<typeof evaluationResponseSchema>;

// Result structure
export const evaluationResultSchema = z.object({
  totalScore: z.number().min(0).max(20),
  riskCategory: z.string(),
  categoryScores: z.object({
    dataEvaluation: z.number().min(0).max(4),
    biasAndFairness: z.number().min(0).max(4),
    performance: z.number().min(0).max(4),
    transparency: z.number().min(0).max(4),
    riskAssessment: z.number().min(0).max(4),
  }),
});

export type EvaluationResult = z.infer<typeof evaluationResultSchema>;
