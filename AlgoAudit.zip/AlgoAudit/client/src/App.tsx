import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { NavigationHeader } from "@/components/navigation-header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Database, Scale, Gauge, Eye, Shield, PlayCircle } from "lucide-react";
import logoImage from "@assets/ChatGPT Image Jul 29, 2025, 12_42_40 PM_1753807760335.png";
import EvaluationPage from "@/pages/evaluation";
import ResultsPage from "@/pages/results";
import NotFound from "@/pages/not-found";

function HomePage() {
  const categories = [
    {
      name: "Data Evaluation",
      icon: Database,
      description: "Assess data reliability and completeness",
      color: "blue"
    },
    {
      name: "Bias Testing",
      icon: Scale,
      description: "Identify and mitigate potential biases",
      color: "green"
    },
    {
      name: "Performance",
      icon: Gauge,
      description: "Evaluate consistency and resilience",
      color: "orange"
    },
    {
      name: "Transparency",
      icon: Eye,
      description: "Ensure accountability and clarity",
      color: "purple"
    },
    {
      name: "Risk Assessment",
      icon: Shield,
      description: "Monitor and mitigate ongoing risks",
      color: "red"
    }
  ];

  const scoreRanges = [
    { range: "16-20", level: "Low Risk", description: "Excellent", color: "text-success" },
    { range: "10-15", level: "Moderate Risk", description: "Needs Improvement", color: "text-info" },
    { range: "5-9", level: "High Risk", description: "Significant Issues", color: "text-warning" },
    { range: "0-4", level: "Critical Risk", description: "Severe Problems", color: "text-destructive" }
  ];

  return (
    <div className="min-h-screen bg-background">
      <NavigationHeader />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="mb-12">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <img 
                src={logoImage} 
                alt="SDEV520 Logo" 
                className="w-20 h-20 mx-auto mb-4 object-contain"
              />
              <h1 className="text-3xl font-bold text-gray-900 mb-4">SDEV520 Algorithm Evaluation</h1>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto mb-4">
                Comprehensive assessment tool for evaluating AI algorithms and implementations across five critical evaluation categories.
              </p>
              <div className="bg-purple-100 rounded-lg p-4 max-w-2xl mx-auto">
                <div className="flex items-center justify-center mb-2">
                  <Shield className="text-purple-600 w-5 h-5 mr-2" />
                  <span className="font-semibold text-purple-800">New: Compliance Framework Support</span>
                </div>
                <p className="text-sm text-purple-700">
                  Now includes industry-specific compliance questions for SOC 2, HIPAA, HITRUST, PCI DSS, NIST, GDPR, and ISO 27001
                </p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
              {categories.map((category, index) => {
                const IconComponent = category.icon;
                const colorClasses = {
                  blue: "bg-blue-100 text-blue-600",
                  green: "bg-green-100 text-green-600",
                  orange: "bg-orange-100 text-orange-600",
                  purple: "bg-purple-100 text-purple-600",
                  red: "bg-red-100 text-red-600"
                };
                
                return (
                  <div key={index} className="bg-gray-50 rounded-lg p-4 text-center">
                    <div className={`w-12 h-12 ${colorClasses[category.color as keyof typeof colorClasses]} rounded-lg flex items-center justify-center mx-auto mb-3`}>
                      <IconComponent className="w-6 h-6" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2">{category.name}</h3>
                    <p className="text-sm text-gray-600">{category.description}</p>
                  </div>
                );
              })}
            </div>

            <div className="bg-blue-50 rounded-lg p-6 mb-8">
              <h3 className="font-semibold text-gray-900 mb-3">Scoring System</h3>
              <div className="grid md:grid-cols-4 gap-4 text-sm">
                {scoreRanges.map((score, index) => (
                  <div key={index} className="text-center">
                    <div className={`text-2xl font-bold mb-1 ${score.color}`}>{score.range}</div>
                    <div className={`font-medium ${score.color}`}>{score.level}</div>
                    <div className="text-gray-600">{score.description}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Compliance Frameworks */}
            <div className="bg-purple-50 rounded-lg p-6 mb-8">
              <div className="flex items-center mb-4">
                <Shield className="text-purple-600 w-6 h-6 mr-2" />
                <h3 className="font-semibold text-gray-900">Supported Compliance Frameworks</h3>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="font-medium text-gray-900">SOC 2</div>
                  <div className="text-purple-600">Security & Availability</div>
                </div>
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="font-medium text-gray-900">HIPAA</div>
                  <div className="text-purple-600">Healthcare Privacy</div>
                </div>
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="font-medium text-gray-900">PCI DSS</div>
                  <div className="text-purple-600">Payment Security</div>
                </div>
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="font-medium text-gray-900">GDPR</div>
                  <div className="text-purple-600">Data Protection</div>
                </div>
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="font-medium text-gray-900">NIST CSF</div>
                  <div className="text-purple-600">Cybersecurity</div>
                </div>
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="font-medium text-gray-900">HITRUST</div>
                  <div className="text-purple-600">Healthcare Security</div>
                </div>
                <div className="text-center p-3 bg-white rounded-lg">
                  <div className="font-medium text-gray-900">ISO 27001</div>
                  <div className="text-purple-600">Info Security</div>
                </div>
                <div className="text-center p-3 bg-white rounded-lg border-2 border-dashed border-purple-300">
                  <div className="font-medium text-gray-700">More Coming</div>
                  <div className="text-purple-600 text-xs">Industry Specific</div>
                </div>
              </div>
            </div>

            <div className="text-center">
              <Link href="/evaluation">
                <Button size="lg" className="text-lg px-8 py-3">
                  <PlayCircle className="mr-2 h-5 w-5" />
                  Start Algorithm Evaluation
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        {/* Documentation Section */}
        <Card>
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">SDEV520 Documentation</h2>
            
            <div className="prose max-w-none">
              <div className="bg-blue-50 rounded-lg p-6 mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Purpose and Framework</h3>
                <p className="text-gray-700 leading-relaxed">
                  The SDEV520 Score is a structured evaluation and scoring system designed to provide engineers, developers, and organizations with a quantifiable method to assess the accuracy, reliability, and effectiveness of programs, software, algorithms, and AI-based solutions.
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Evaluation Categories</h4>
                  <ul className="space-y-2 text-sm text-gray-700">
                    <li className="flex items-center space-x-2">
                      <Database className="text-primary w-4 h-4" />
                      <span>Data Evaluation - Reliability and completeness</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Scale className="text-success w-4 h-4" />
                      <span>Bias and Fairness Testing - Identifying biases</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Gauge className="text-warning w-4 h-4" />
                      <span>Output and Performance Evaluation</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Eye className="text-purple-600 w-4 h-4" />
                      <span>Transparency and Explainability</span>
                    </li>
                    <li className="flex items-center space-x-2">
                      <Shield className="text-destructive w-4 h-4" />
                      <span>Post-Deployment Monitoring</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Scoring Algorithm</h4>
                  <div className="text-sm text-gray-700 space-y-2">
                    <p>Binary scoring system: Yes = 1 point, No = 0 points</p>
                    <p>Total questions: 20 (4 per category)</p>
                    <p>Score range: 0-20</p>
                    <div className="mt-4 space-y-1">
                      {scoreRanges.map((score, index) => (
                        <div key={index} className="flex justify-between">
                          <span>{score.range}: {score.level}</span>
                          <span className={`font-medium ${score.color}`}>{score.description}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-yellow-50 rounded-lg p-6">
                <h4 className="font-semibold text-gray-900 mb-3">Implementation Guidelines</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Complete all 20 questions for accurate assessment</li>
                  <li>• Consider each question carefully in the context of your specific algorithm</li>
                  <li>• Document rationale for each answer to support audit trails</li>
                  <li>• Re-evaluate periodically as algorithms evolve and improve</li>
                  <li>• Use results to prioritize improvement efforts in low-scoring areas</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img 
                src={logoImage} 
                alt="SDEV520 Logo" 
                className="w-6 h-6 object-contain"
              />
              <div className="text-sm text-gray-600">
                SDEV520 Algorithm Evaluation Tool
              </div>
            </div>
            <div className="text-sm text-gray-500">
              © 2025 Spivey GCEF Algorithm Evaluation. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/evaluation" component={EvaluationPage} />
      <Route path="/results/:id" component={ResultsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
