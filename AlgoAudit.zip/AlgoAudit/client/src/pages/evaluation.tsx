import { NavigationHeader } from "@/components/navigation-header";
import { EvaluationForm } from "@/components/evaluation-form";

export default function EvaluationPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      <EvaluationForm />
    </div>
  );
}
