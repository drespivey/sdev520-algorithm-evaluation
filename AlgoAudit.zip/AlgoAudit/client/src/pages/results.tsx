import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { NavigationHeader } from "@/components/navigation-header";
import { ScoreDisplay } from "@/components/score-display";
import { CategoryBreakdown } from "@/components/category-breakdown";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, RefreshCw, Save, CheckCircle, XCircle, BarChart3, Shield } from "lucide-react";
import { evaluationQuestions } from "@/lib/evaluation-data";
import { getFrameworkById } from "@/lib/compliance-data";
import { Evaluation } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

export default function ResultsPage() {
  const { id } = useParams();
  const { toast } = useToast();

  const { data: evaluation, isLoading, error } = useQuery<Evaluation>({
    queryKey: ["/api/evaluations", id],
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <NavigationHeader />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">Loading evaluation results...</div>
        </div>
      </div>
    );
  }

  if (error || !evaluation) {
    return (
      <div className="min-h-screen bg-gray-50">
        <NavigationHeader />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card>
            <CardContent className="p-8 text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Evaluation Not Found</h2>
              <p className="text-gray-600 mb-6">The requested evaluation could not be found.</p>
              <Link href="/">
                <Button>Return to Home</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const responses = evaluation.responses as boolean[];
  const categoryScores = evaluation.categoryScores as {
    dataEvaluation: number;
    biasAndFairness: number;
    performance: number;
    transparency: number;
    riskAssessment: number;
  };
  const complianceFrameworks = evaluation.complianceFrameworks as string[] || [];
  const complianceResponses = evaluation.complianceResponses as Record<string, boolean[]> || {};
  const complianceBreakdown = evaluation.complianceBreakdown as Record<string, number> || {};

  const generateDetailedReport = () => {
    let report = `
SDEV520 Algorithm Evaluation Report
===================================

EVALUATION SUMMARY
Algorithm Name: ${evaluation.algorithmName}
Evaluator: ${evaluation.evaluatorName}
Industry: ${evaluation.industry || 'Not specified'}
Evaluation Date: ${new Date(evaluation.createdAt).toLocaleDateString()}
Report ID: ${evaluation.id}

EXECUTIVE SUMMARY
================
Overall SDEV520 Score: ${evaluation.totalScore}/20 (${Math.round((evaluation.totalScore / 20) * 100)}%)
Risk Classification: ${evaluation.riskCategory}

Risk Assessment:
${evaluation.riskCategory === 'Low Risk' ? '✓ EXCELLENT - Algorithm meets high standards with minimal risk factors' : 
  evaluation.riskCategory === 'Moderate Risk' ? '⚠ NEEDS IMPROVEMENT - Some areas require attention to reduce risk' :
  evaluation.riskCategory === 'High Risk' ? '⚠ SIGNIFICANT ISSUES - Multiple areas need immediate improvement' :
  '❌ CRITICAL RISK - Urgent remediation required before deployment'}

CORE SDEV520 EVALUATION RESULTS
===============================
Category Performance:
- Data Evaluation: ${categoryScores.dataEvaluation}/4 (${Math.round((categoryScores.dataEvaluation / 4) * 100)}%)
- Bias and Fairness Testing: ${categoryScores.biasAndFairness}/4 (${Math.round((categoryScores.biasAndFairness / 4) * 100)}%)
- Performance Evaluation: ${categoryScores.performance}/4 (${Math.round((categoryScores.performance / 4) * 100)}%)
- Transparency and Explainability: ${categoryScores.transparency}/4 (${Math.round((categoryScores.transparency / 4) * 100)}%)
- Risk Assessment: ${categoryScores.riskAssessment}/4 (${Math.round((categoryScores.riskAssessment / 4) * 100)}%)

DETAILED QUESTION ANALYSIS
==========================
${evaluationQuestions.map((q, index) => `
Question ${index + 1}: ${q.question}
Category: ${q.category}
Response: ${responses[index] ? '✓ YES' : '✗ NO'}
Impact: ${responses[index] ? 'Positive compliance indicator' : 'Area requiring attention'}
`).join('')}`;

    // Add compliance section if applicable
    if (complianceFrameworks.length > 0) {
      report += `

COMPLIANCE FRAMEWORK ASSESSMENT
==============================
Overall Compliance Score: ${evaluation.complianceScore || 0}%
Number of Frameworks Evaluated: ${complianceFrameworks.length}
Compliance Status: ${(evaluation.complianceScore || 0) >= 90 ? 'EXCELLENT' : 
                    (evaluation.complianceScore || 0) >= 80 ? 'GOOD' :
                    (evaluation.complianceScore || 0) >= 70 ? 'ADEQUATE' : 'NEEDS IMPROVEMENT'}

Framework-Specific Results:
${complianceFrameworks.map(frameworkId => {
  const framework = getFrameworkById(frameworkId);
  const score = complianceBreakdown[frameworkId] || 0;
  const frameworkResponses = complianceResponses[frameworkId] || [];
  
  if (!framework) return '';
  
  const percentage = Math.round((score / framework.questions.length) * 100);
  return `
${framework.name.toUpperCase()}
Score: ${score}/${framework.questions.length} (${percentage}%)
Description: ${framework.description}
Compliance Level: ${percentage >= 90 ? 'FULLY COMPLIANT' : percentage >= 80 ? 'MOSTLY COMPLIANT' : percentage >= 70 ? 'PARTIALLY COMPLIANT' : 'NON-COMPLIANT'}

Detailed Questions:
${framework.questions.map((q, index) => `
  ${index + 1}. ${q.question}
      Response: ${frameworkResponses[index] ? '✓ COMPLIANT' : '✗ NON-COMPLIANT'}
      Category: ${q.category}
      ${!frameworkResponses[index] ? 'ACTION REQUIRED: Review and implement controls for this requirement' : 'Status: Requirement satisfied'}
`).join('')}`;
}).join('')}`;
    }

    // Enhanced recommendations
    const recommendations = [];
    if (categoryScores.dataEvaluation < 3) recommendations.push('Data Evaluation: Improve data quality, validation, and reliability processes');
    if (categoryScores.biasAndFairness < 3) recommendations.push('Bias Testing: Implement comprehensive fairness testing and bias mitigation strategies');
    if (categoryScores.performance < 3) recommendations.push('Performance: Enhance consistency, resilience, and performance monitoring');
    if (categoryScores.transparency < 3) recommendations.push('Transparency: Improve explainability and documentation practices');
    if (categoryScores.riskAssessment < 3) recommendations.push('Risk Assessment: Strengthen ongoing monitoring and risk management procedures');
    
    report += `

RECOMMENDATIONS AND ACTION ITEMS
===============================
Priority Areas for Improvement:
${recommendations.length > 0 ? recommendations.map((rec, index) => `${index + 1}. ${rec}`).join('\n') : 'All core categories meet acceptable standards. Continue monitoring and improvement.'}

${complianceFrameworks.length > 0 && (evaluation.complianceScore || 0) < 80 ? `
Compliance Improvement:
- Review non-compliant items in each framework
- Develop remediation plan for gaps identified
- Consider additional training or process improvements
- Schedule follow-up evaluation after improvements
` : ''}

NEXT STEPS
==========
1. Review all areas marked as requiring attention
2. Develop improvement plan with timeline and ownership
3. Implement necessary changes and controls
4. Schedule re-evaluation in 3-6 months
5. Document lessons learned and best practices

---
Report Generated: ${new Date().toLocaleString()}
Generated by: SDEV520 Algorithm Evaluation Tool
Report Version: 1.0
    `;

    return report;
  };

  const handleExportTxtReport = () => {
    const report = generateDetailedReport();
    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SDEV520_Report_${evaluation.algorithmName.replace(/[^a-z0-9]/gi, '_')}_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "Report Downloaded",
      description: "Your detailed SDEV520 evaluation report has been downloaded as a text file.",
    });
  };

  const handleExportCsvReport = () => {
    // Create CSV format for data analysis
    let csvContent = "Category,Question,Response,Score\n";
    
    // Add core questions
    evaluationQuestions.forEach((q, index) => {
      csvContent += `"${q.category}","${q.question}","${responses[index] ? 'Yes' : 'No'}","${responses[index] ? 1 : 0}"\n`;
    });
    
    // Add compliance questions if applicable
    complianceFrameworks.forEach(frameworkId => {
      const framework = getFrameworkById(frameworkId);
      const frameworkResponses = complianceResponses[frameworkId] || [];
      
      if (framework) {
        framework.questions.forEach((q, index) => {
          csvContent += `"${framework.name} - ${q.category}","${q.question}","${frameworkResponses[index] ? 'Compliant' : 'Non-Compliant'}","${frameworkResponses[index] ? 1 : 0}"\n`;
        });
      }
    });

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `SDEV520_Data_${evaluation.algorithmName.replace(/[^a-z0-9]/gi, '_')}_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    
    toast({
      title: "CSV Data Downloaded",
      description: "Evaluation data exported in CSV format for analysis.",
    });
  };

  const handlePrintReport = () => {
    const printContent = generateDetailedReport().replace(/\n/g, '<br>');
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>SDEV520 Evaluation Report - ${evaluation.algorithmName}</title>
            <style>
              body { font-family: Arial, sans-serif; line-height: 1.6; margin: 40px; }
              h1, h2 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
              .summary { background: #f8f9fa; padding: 20px; border-left: 4px solid #007bff; margin: 20px 0; }
              pre { white-space: pre-wrap; font-family: Arial, sans-serif; }
            </style>
          </head>
          <body>
            <pre>${printContent}</pre>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const categoryQuestions = {
    "Data Evaluation": evaluationQuestions.slice(0, 4),
    "Bias and Fairness Testing": evaluationQuestions.slice(4, 8),
    "Output and Performance Evaluation": evaluationQuestions.slice(8, 12),
    "Transparency and Explainability": evaluationQuestions.slice(12, 16),
    "Post-Deployment Monitoring & Risk Assessment": evaluationQuestions.slice(16, 20),
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavigationHeader />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Card className="mb-8">
          <CardContent className="p-8">
            <div className="text-center mb-8">
              <div className="w-20 h-20 bg-success rounded-full flex items-center justify-center mx-auto mb-4">
                <BarChart3 className="text-white w-10 h-10" />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Evaluation Complete</h2>
              <p className="text-lg text-gray-600">Algorithm: {evaluation.algorithmName}</p>
              <p className="text-sm text-gray-500">Evaluated by: {evaluation.evaluatorName}</p>
            </div>

            <ScoreDisplay 
              score={evaluation.totalScore} 
              riskCategory={evaluation.riskCategory} 
            />

            <CategoryBreakdown categoryScores={categoryScores} />

            {/* Compliance Score Display */}
            {complianceFrameworks.length > 0 && (
              <div className="mb-8">
                <div className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-xl p-8 mb-6">
                  <div className="text-center">
                    <div className="flex items-center justify-center mb-4">
                      <Shield className="text-purple-600 w-8 h-8 mr-3" />
                      <h3 className="text-2xl font-bold text-gray-900">Compliance Assessment</h3>
                    </div>
                    <div className="text-4xl font-bold text-purple-600 mb-2">
                      {evaluation.complianceScore || 0}%
                    </div>
                    <p className="text-gray-600 mb-4">Overall Compliance Score</p>
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {complianceFrameworks.map((frameworkId) => {
                        const framework = getFrameworkById(frameworkId);
                        const score = complianceBreakdown[frameworkId] || 0;
                        const totalQuestions = framework?.questions.length || 0;
                        const percentage = totalQuestions > 0 ? Math.round((score / totalQuestions) * 100) : 0;
                        
                        return (
                          <div key={frameworkId} className="bg-white rounded-lg p-4 text-center">
                            <h4 className="font-semibold text-gray-900 mb-1">{framework?.name}</h4>
                            <div className="text-2xl font-bold text-purple-600">
                              {score}/{totalQuestions}
                            </div>
                            <div className="text-sm text-gray-600">{percentage}% compliant</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Detailed Results */}
            <div className="space-y-6 mb-8">
              <h3 className="text-xl font-semibold text-gray-900">Detailed Results</h3>
              
              {Object.entries(categoryQuestions).map(([categoryName, questions], categoryIndex) => {
                const categoryScore = Object.values(categoryScores)[categoryIndex];
                
                return (
                  <div key={categoryName} className="border border-gray-200 rounded-lg overflow-hidden">
                    <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                      <div className="flex items-center justify-between">
                        <h4 className="font-semibold text-gray-900">{categoryName}</h4>
                        <div className="text-sm text-gray-600">{categoryScore}/4 questions passed</div>
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {questions.map((question, questionIndex) => {
                          const absoluteIndex = categoryIndex * 4 + questionIndex;
                          const answer = responses[absoluteIndex];
                          
                          return (
                            <div key={question.id} className="flex items-start space-x-3">
                              <div className="flex-shrink-0 mt-1">
                                {answer ? (
                                  <CheckCircle className="text-success w-5 h-5" />
                                ) : (
                                  <XCircle className="text-destructive w-5 h-5" />
                                )}
                              </div>
                              <div className="flex-1">
                                <p className="text-gray-800">{question.question}</p>
                                <p className="text-sm text-gray-600 mt-1">
                                  Answer: <span className={answer ? "text-success" : "text-destructive"}>
                                    {answer ? "Yes" : "No"}
                                  </span>
                                </p>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </CardContent>
                  </div>
                );
              })}

              {/* Personalized Recommendations */}
              <div className="mt-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-6 flex items-center">
                  <CheckCircle className="text-blue-600 w-6 h-6 mr-2" />
                  Personalized Improvement Recommendations
                </h3>
                
                {(() => {
                  const failedQuestions = evaluationQuestions.filter((question, index) => !responses[index]);
                  const failedComplianceQuestions = complianceFrameworks.flatMap(frameworkId => {
                    const framework = getFrameworkById(frameworkId);
                    const frameworkResponses = complianceResponses[frameworkId] || [];
                    return framework?.questions.filter((_, index) => !frameworkResponses[index]) || [];
                  });
                  
                  const totalFailedQuestions = failedQuestions.length + failedComplianceQuestions.length;
                  
                  if (totalFailedQuestions === 0) {
                    return (
                      <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                        <div className="flex items-center">
                          <CheckCircle className="text-green-600 w-8 h-8 mr-3" />
                          <div>
                            <h4 className="font-semibold text-green-900">Excellent Performance!</h4>
                            <p className="text-green-700 mt-1">
                              Your algorithm meets all evaluation criteria. Continue monitoring and maintaining these high standards.
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  }
                  
                  return (
                    <div className="space-y-6">
                      <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                        <p className="text-orange-800">
                          <strong>{totalFailedQuestions}</strong> areas identified for improvement. 
                          Below are specific recommendations to enhance your algorithm's compliance and performance.
                        </p>
                      </div>
                      
                      {/* Core SDEV520 Recommendations */}
                      {failedQuestions.length > 0 && (
                        <div className="border border-blue-200 rounded-lg overflow-hidden">
                          <div className="bg-blue-50 px-6 py-4 border-b border-blue-200">
                            <h4 className="font-semibold text-gray-900 flex items-center">
                              <BarChart3 className="text-blue-600 w-5 h-5 mr-2" />
                              Core SDEV520 Improvements ({failedQuestions.length} areas)
                            </h4>
                          </div>
                          <CardContent className="p-6">
                            <div className="space-y-6">
                              {failedQuestions.map((question, index) => (
                                <div key={question.id} className="border-l-4 border-orange-400 pl-4">
                                  <div className="flex items-start space-x-3">
                                    <XCircle className="text-orange-500 w-5 h-5 flex-shrink-0 mt-1" />
                                    <div className="flex-1">
                                      <h5 className="font-semibold text-gray-900 mb-2">{question.category}</h5>
                                      <p className="text-gray-800 mb-2">{question.question}</p>
                                      <div className="bg-blue-50 rounded-lg p-4 mt-3">
                                        <h6 className="font-medium text-blue-900 mb-2">💡 Recommended Actions:</h6>
                                        <p className="text-blue-800 text-sm leading-relaxed">{question.recommendation}</p>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </div>
                      )}
                      
                      {/* Compliance Recommendations */}
                      {failedComplianceQuestions.length > 0 && (
                        <div className="border border-purple-200 rounded-lg overflow-hidden">
                          <div className="bg-purple-50 px-6 py-4 border-b border-purple-200">
                            <h4 className="font-semibold text-gray-900 flex items-center">
                              <Shield className="text-purple-600 w-5 h-5 mr-2" />
                              Compliance Framework Improvements ({failedComplianceQuestions.length} areas)
                            </h4>
                          </div>
                          <CardContent className="p-6">
                            <div className="space-y-6">
                              {failedComplianceQuestions.map((question, index) => (
                                <div key={question.id} className="border-l-4 border-purple-400 pl-4">
                                  <div className="flex items-start space-x-3">
                                    <XCircle className="text-purple-500 w-5 h-5 flex-shrink-0 mt-1" />
                                    <div className="flex-1">
                                      <h5 className="font-semibold text-gray-900 mb-2">{question.category}</h5>
                                      <p className="text-gray-800 mb-2">{question.question}</p>
                                      <div className="bg-purple-50 rounded-lg p-4 mt-3">
                                        <h6 className="font-medium text-purple-900 mb-2">🔒 Compliance Actions:</h6>
                                        <p className="text-purple-800 text-sm leading-relaxed">{question.recommendation}</p>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </CardContent>
                        </div>
                      )}
                    </div>
                  );
                })()}
              </div>

              {/* Compliance Framework Results */}
              {complianceFrameworks.length > 0 && (
                <div className="mt-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-6">Compliance Framework Results</h3>
                  {complianceFrameworks.map((frameworkId) => {
                    const framework = getFrameworkById(frameworkId);
                    const frameworkResponses = complianceResponses[frameworkId] || [];
                    const score = complianceBreakdown[frameworkId] || 0;
                    
                    if (!framework) return null;
                    
                    return (
                      <div key={frameworkId} className="border border-purple-200 rounded-lg overflow-hidden mb-6">
                        <div className="bg-purple-50 px-6 py-4 border-b border-purple-200">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <Shield className="text-purple-600 w-5 h-5 mr-2" />
                              <h4 className="font-semibold text-gray-900">{framework.name}</h4>
                            </div>
                            <div className="text-sm text-gray-600">
                              {score}/{framework.questions.length} requirements met ({Math.round((score / framework.questions.length) * 100)}%)
                            </div>
                          </div>
                          <p className="text-sm text-gray-600 mt-1">{framework.description}</p>
                        </div>
                        <CardContent className="p-6">
                          <div className="space-y-4">
                            {framework.questions.map((question, questionIndex) => {
                              const answer = frameworkResponses[questionIndex];
                              
                              return (
                                <div key={question.id} className="flex items-start space-x-3">
                                  <div className="flex-shrink-0 mt-1">
                                    {answer ? (
                                      <CheckCircle className="text-success w-5 h-5" />
                                    ) : (
                                      <XCircle className="text-destructive w-5 h-5" />
                                    )}
                                  </div>
                                  <div className="flex-1">
                                    <div className="flex items-start justify-between">
                                      <div className="flex-1">
                                        <p className="font-medium text-gray-900">{question.category}</p>
                                        <p className="text-gray-800 mt-1">{question.question}</p>
                                        <p className="text-sm text-gray-600 mt-1">{question.description}</p>
                                      </div>
                                      <div className="ml-4 text-right">
                                        <span className={`text-sm font-medium ${answer ? "text-success" : "text-destructive"}`}>
                                          {answer ? "Compliant" : "Non-Compliant"}
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </CardContent>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="space-y-4">
              <div className="text-center">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Export Your Assessment Report</h3>
                <div className="flex flex-wrap items-center justify-center gap-3">
                  <Button onClick={handleExportTxtReport} className="flex items-center">
                    <Download className="mr-2 h-4 w-4" />
                    Download Full Report
                  </Button>
                  <Button onClick={handleExportCsvReport} variant="outline" className="flex items-center">
                    <Download className="mr-2 h-4 w-4" />
                    Export Data (CSV)
                  </Button>
                  <Button onClick={handlePrintReport} variant="outline" className="flex items-center">
                    <Save className="mr-2 h-4 w-4" />
                    Print Report
                  </Button>
                </div>
                <p className="text-sm text-gray-600 mt-3">
                  Get your complete SDEV520 evaluation in multiple formats for documentation and compliance purposes
                </p>
              </div>
              
              <div className="flex items-center justify-center pt-4 border-t">
                <Link href="/evaluation">
                  <Button variant="outline" className="flex items-center">
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Start New Evaluation
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
