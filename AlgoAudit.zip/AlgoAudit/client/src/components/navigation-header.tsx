import { Link, useLocation } from "wouter";
import logoImage from "@assets/ChatGPT Image Jul 29, 2025, 12_42_40 PM_1753807760335.png";

export function NavigationHeader() {
  const [location] = useLocation();
  
  const isActive = (path: string) => {
    if (path === "/" && location === "/") return true;
    if (path !== "/" && location.startsWith(path)) return true;
    return false;
  };

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center space-x-3">
            <img 
              src={logoImage} 
              alt="SDEV520 Logo" 
              className="w-10 h-10 object-contain"
            />
            <div>
              <h1 className="text-xl font-semibold text-gray-900">SDEV520</h1>
              <p className="text-xs text-gray-500">Algorithm Evaluation Tool</p>
            </div>
          </Link>
          <nav className="hidden md:flex space-x-6">
            <Link href="/" className={`font-medium ${isActive("/") ? "text-primary" : "text-gray-600 hover:text-gray-900"}`}>
              Overview
            </Link>
            <Link href="/evaluation" className={`font-medium ${isActive("/evaluation") ? "text-primary" : "text-gray-600 hover:text-gray-900"}`}>
              Evaluation
            </Link>
            <Link href="/results" className={`font-medium ${isActive("/results") ? "text-primary" : "text-gray-600 hover:text-gray-900"}`}>
              Results
            </Link>
          </nav>
        </div>
      </div>
    </header>
  );
}
