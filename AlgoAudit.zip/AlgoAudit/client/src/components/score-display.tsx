import { cn } from "@/lib/utils";

interface ScoreDisplayProps {
  score: number;
  riskCategory: string;
}

export function ScoreDisplay({ score, riskCategory }: ScoreDisplayProps) {
  const getScoreColor = (score: number) => {
    if (score >= 16) return "text-success";
    if (score >= 10) return "text-info";
    if (score >= 5) return "text-warning";
    return "text-destructive";
  };

  const getRiskColor = (category: string) => {
    if (category.includes("Low Risk")) return "text-success";
    if (category.includes("Moderate Risk")) return "text-info";
    if (category.includes("High Risk")) return "text-warning";
    return "text-destructive";
  };

  const getDescription = (category: string) => {
    if (category.includes("Low Risk")) {
      return "Your algorithm meets high standards across all evaluation categories. The implementation demonstrates strong data integrity, fairness, and reliability.";
    }
    if (category.includes("Moderate Risk")) {
      return "Your algorithm shows good performance but has areas for improvement. Focus on the lower-scoring categories to enhance overall reliability.";
    }
    if (category.includes("High Risk")) {
      return "Your algorithm has significant issues that need attention. Review and address the identified problems before deployment.";
    }
    return "Your algorithm has critical problems that make it unsuitable for deployment. Comprehensive review and redesign are required.";
  };

  return (
    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-8 mb-8">
      <div className="text-center">
        <div className={cn("text-6xl font-bold mb-4", getScoreColor(score))}>
          {score}<span className="text-3xl text-gray-400">/20</span>
        </div>
        <div className={cn("text-2xl font-semibold mb-2", getRiskColor(riskCategory))}>
          {riskCategory}
        </div>
        <p className="text-gray-600 max-w-2xl mx-auto">
          {getDescription(riskCategory)}
        </p>
      </div>
    </div>
  );
}
