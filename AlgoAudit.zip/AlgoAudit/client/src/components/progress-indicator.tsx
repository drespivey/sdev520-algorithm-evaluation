import { cn } from "@/lib/utils";

interface ProgressIndicatorProps {
  currentQuestion: number;
  totalQuestions: number;
  categoryProgress: number[];
}

export function ProgressIndicator({ currentQuestion, totalQuestions, categoryProgress }: ProgressIndicatorProps) {
  const progressPercentage = (currentQuestion / totalQuestions) * 100;
  
  const categories = [
    { name: "Data", index: 0 },
    { name: "Bias", index: 1 },
    { name: "Performance", index: 2 },
    { name: "Transparency", index: 3 },
    { name: "Risk", index: 4 }
  ];

  const getCurrentCategory = (questionIndex: number) => Math.floor(questionIndex / 4);
  const currentCategoryIndex = getCurrentCategory(currentQuestion - 1);

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-2xl font-bold text-gray-900">Algorithm Evaluation</h2>
        <div className="text-sm text-gray-600">
          {currentQuestion} of {totalQuestions}
        </div>
      </div>
      
      <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
        <div 
          className="bg-primary h-2 rounded-full transition-all duration-300"
          style={{ width: `${progressPercentage}%` }}
        />
      </div>
      
      <div className="grid grid-cols-5 gap-2 mb-6">
        {categories.map((category, index) => {
          const isComplete = categoryProgress[index] >= 4;
          const isCurrent = index === currentCategoryIndex;
          const isUpcoming = index > currentCategoryIndex;
          
          return (
            <div key={category.index} className="text-center">
              <div className={cn(
                "w-8 h-8 rounded-full text-sm flex items-center justify-center mx-auto mb-1 font-medium",
                isComplete && "bg-success text-white",
                isCurrent && !isComplete && "bg-primary text-white", 
                isUpcoming && "bg-gray-300 text-gray-600"
              )}>
                {index + 1}
              </div>
              <div className="text-xs text-gray-600">{category.name}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
