import { Card, CardContent } from "@/components/ui/card";
import { Database, Scale, Gauge, Eye, Shield } from "lucide-react";

interface CategoryScore {
  dataEvaluation: number;
  biasAndFairness: number;
  performance: number;
  transparency: number;
  riskAssessment: number;
}

interface CategoryBreakdownProps {
  categoryScores: CategoryScore;
}

export function CategoryBreakdown({ categoryScores }: CategoryBreakdownProps) {
  const categories = [
    {
      name: "Data Evaluation",
      icon: Database,
      score: categoryScores.dataEvaluation,
      color: "blue",
      bgColor: "bg-blue-100",
      textColor: "text-blue-600"
    },
    {
      name: "Bias Testing",
      icon: Scale,
      score: categoryScores.biasAndFairness,
      color: "green",
      bgColor: "bg-green-100", 
      textColor: "text-green-600"
    },
    {
      name: "Performance",
      icon: Gauge,
      score: categoryScores.performance,
      color: "orange",
      bgColor: "bg-orange-100",
      textColor: "text-orange-600"
    },
    {
      name: "Transparency",
      icon: Eye,
      score: categoryScores.transparency,
      color: "purple",
      bgColor: "bg-purple-100",
      textColor: "text-purple-600"
    },
    {
      name: "Risk Assessment",
      icon: Shield,
      score: categoryScores.riskAssessment,
      color: "red",
      bgColor: "bg-red-100",
      textColor: "text-red-600"
    }
  ];

  const getScoreLabel = (score: number) => {
    if (score === 4) return { label: "Excellent", color: "text-success" };
    if (score === 3) return { label: "Good", color: "text-info" };
    if (score === 2) return { label: "Fair", color: "text-warning" };
    if (score === 1) return { label: "Poor", color: "text-destructive" };
    return { label: "Critical", color: "text-destructive" };
  };

  return (
    <div className="grid md:grid-cols-5 gap-6 mb-8">
      {categories.map((category) => {
        const IconComponent = category.icon;
        const scoreInfo = getScoreLabel(category.score);
        
        return (
          <Card key={category.name} className="bg-gray-50">
            <CardContent className="p-6 text-center">
              <div className={`w-12 h-12 ${category.bgColor} rounded-lg flex items-center justify-center mx-auto mb-3`}>
                <IconComponent className={`${category.textColor} w-6 h-6`} />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">{category.name}</h3>
              <div className="text-2xl font-bold text-primary mb-1">
                {category.score}<span className="text-lg text-gray-400">/4</span>
              </div>
              <div className={`text-xs font-medium ${scoreInfo.color}`}>
                {scoreInfo.label}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
