import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { CheckCircle, XCircle, ChevronLeft, ChevronRight, Shield, Settings } from "lucide-react";
import { evaluationResponseSchema, type EvaluationResponse } from "@shared/schema";
import { evaluationQuestions } from "@/lib/evaluation-data";
import { complianceFrameworks, industries, getFrameworksByIndustry, getFrameworkById } from "@/lib/compliance-data";
import { ProgressIndicator } from "./progress-indicator";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export function EvaluationForm() {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [responses, setResponses] = useState<(boolean | null)[]>(new Array(20).fill(null));
  const [selectedFrameworks, setSelectedFrameworks] = useState<string[]>([]);
  const [complianceResponses, setComplianceResponses] = useState<Record<string, (boolean | null)[]>>({});
  const [showComplianceQuestions, setShowComplianceQuestions] = useState(false);
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const form = useForm<EvaluationResponse>({
    resolver: zodResolver(evaluationResponseSchema),
    defaultValues: {
      algorithmName: "",
      evaluatorName: "",
      industry: "",
      complianceFrameworks: [],
      responses: [],
      complianceResponses: {}
    }
  });

  const submitEvaluation = useMutation({
    mutationFn: async (data: EvaluationResponse) => {
      const response = await apiRequest("POST", "/api/evaluations", data);
      return response.json();
    },
    onSuccess: (evaluation) => {
      toast({
        title: "Evaluation Submitted",
        description: "Your evaluation has been successfully completed.",
      });
      setLocation(`/results/${evaluation.id}`);
    },
    onError: (error) => {
      toast({
        title: "Submission Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const currentQuestion = evaluationQuestions[currentQuestionIndex];
  const isFirstQuestion = currentQuestionIndex === 0;
  const isLastQuestion = currentQuestionIndex === evaluationQuestions.length - 1;

  const getCurrentScore = () => {
    return responses.reduce((sum, response) => sum + (response ? 1 : 0), 0);
  };

  const getCategoryProgress = () => {
    const progress = [0, 0, 0, 0, 0];
    responses.forEach((response, index) => {
      if (response !== null) {
        const categoryIndex = Math.floor(index / 4);
        progress[categoryIndex]++;
      }
    });
    return progress;
  };

  const handleAnswerChange = (value: string) => {
    const newResponses = [...responses];
    newResponses[currentQuestionIndex] = value === "1";
    setResponses(newResponses);
  };

  const handleNext = () => {
    if (currentQuestionIndex < evaluationQuestions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleFrameworkToggle = (frameworkId: string, checked: boolean) => {
    if (checked) {
      setSelectedFrameworks(prev => [...prev, frameworkId]);
      const framework = getFrameworkById(frameworkId);
      if (framework) {
        setComplianceResponses(prev => ({
          ...prev,
          [frameworkId]: new Array(framework.questions.length).fill(null)
        }));
      }
    } else {
      setSelectedFrameworks(prev => prev.filter(f => f !== frameworkId));
      setComplianceResponses(prev => {
        const newResponses = { ...prev };
        delete newResponses[frameworkId];
        return newResponses;
      });
    }
  };

  const handleComplianceAnswerChange = (frameworkId: string, questionIndex: number, value: string) => {
    setComplianceResponses(prev => ({
      ...prev,
      [frameworkId]: prev[frameworkId]?.map((response, index) => 
        index === questionIndex ? value === "1" : response
      ) || []
    }));
  };

  const handleSubmit = () => {
    if (!form.getValues("algorithmName") || !form.getValues("evaluatorName")) {
      toast({
        title: "Missing Information",
        description: "Please provide algorithm name and evaluator name before submitting.",
        variant: "destructive",
      });
      return;
    }

    if (responses.some(response => response === null)) {
      toast({
        title: "Incomplete Evaluation",
        description: "Please answer all questions before submitting.",
        variant: "destructive",
      });
      return;
    }

    // Check compliance questions if frameworks are selected
    if (selectedFrameworks.length > 0) {
      const incompleteFrameworks = selectedFrameworks.filter(frameworkId => {
        const responses = complianceResponses[frameworkId];
        return !responses || responses.some(response => response === null);
      });

      if (incompleteFrameworks.length > 0) {
        toast({
          title: "Incomplete Compliance Evaluation",
          description: "Please answer all compliance questions for selected frameworks.",
          variant: "destructive",
        });
        return;
      }
    }

    const data: EvaluationResponse = {
      algorithmName: form.getValues("algorithmName"),
      evaluatorName: form.getValues("evaluatorName"),
      industry: form.getValues("industry"),
      complianceFrameworks: selectedFrameworks,
      responses: responses as boolean[],
      complianceResponses: Object.fromEntries(
        Object.entries(complianceResponses).map(([key, values]) => [key, values as boolean[]])
      )
    };

    submitEvaluation.mutate(data);
  };

  const allQuestionsAnswered = responses.every(response => response !== null);
  const allComplianceQuestionsAnswered = selectedFrameworks.length === 0 || 
    selectedFrameworks.every(frameworkId => {
      const responses = complianceResponses[frameworkId];
      return responses && responses.every(response => response !== null);
    });

  const getTotalComplianceQuestions = () => {
    return selectedFrameworks.reduce((total, frameworkId) => {
      const framework = getFrameworkById(frameworkId);
      return total + (framework ? framework.questions.length : 0);
    }, 0);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Card className="mb-8">
        <CardContent className="p-8">
          <ProgressIndicator
            currentQuestion={currentQuestionIndex + 1}
            totalQuestions={evaluationQuestions.length}
            categoryProgress={getCategoryProgress()}
          />

          {/* Evaluation Details Form - Show only at start */}
          {currentQuestionIndex === 0 && (!form.getValues("algorithmName") || !form.getValues("evaluatorName")) && (
            <div className="mb-8 space-y-6">
              <div className="p-6 bg-blue-50 rounded-lg">
                <h3 className="font-semibold text-gray-900 mb-4">Evaluation Details</h3>
                <Form {...form}>
                  <div className="grid md:grid-cols-2 gap-4 mb-4">
                    <FormField
                      control={form.control}
                      name="algorithmName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Algorithm Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter algorithm name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="evaluatorName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Evaluator Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter your name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={form.control}
                    name="industry"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Industry (Optional)</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select your industry" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {industries.map((industry) => (
                              <SelectItem key={industry} value={industry}>
                                {industry}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </Form>
              </div>

              {/* Compliance Framework Selection */}
              <div className="p-6 bg-purple-50 rounded-lg">
                <div className="flex items-center mb-4">
                  <Shield className="text-purple-600 w-5 h-5 mr-2" />
                  <h3 className="font-semibold text-gray-900">Compliance Frameworks (Optional)</h3>
                </div>
                <p className="text-sm text-gray-600 mb-4">
                  Select additional compliance frameworks to evaluate your algorithm against industry standards.
                </p>
                
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {(form.getValues("industry") ? 
                    getFrameworksByIndustry(form.getValues("industry") || "") : 
                    complianceFrameworks
                  ).map((framework) => (
                    <div key={framework.id} className="flex items-start space-x-3 p-3 bg-white rounded-lg border">
                      <Checkbox
                        id={framework.id}
                        checked={selectedFrameworks.includes(framework.id)}
                        onCheckedChange={(checked) => handleFrameworkToggle(framework.id, checked as boolean)}
                      />
                      <div className="flex-1">
                        <Label htmlFor={framework.id} className="font-medium cursor-pointer">
                          {framework.name}
                        </Label>
                        <p className="text-xs text-gray-600 mt-1">
                          {framework.description}
                        </p>
                        <div className="text-xs text-gray-500 mt-1">
                          {framework.questions.length} questions
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {selectedFrameworks.length > 0 && (
                  <div className="mt-4 p-3 bg-green-50 rounded-lg">
                    <p className="text-sm text-green-800">
                      {selectedFrameworks.length} compliance framework(s) selected. 
                      Additional questions will appear after completing the core SDEV_520 evaluation.
                    </p>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Current Question */}
          <div className="mb-8">
            <div className="bg-blue-50 rounded-lg p-6 mb-6">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white text-sm font-medium">{currentQuestionIndex + 1}</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-2">
                    {currentQuestion.category} - Question {(currentQuestionIndex % 4) + 1}
                  </h3>
                  <p className="text-gray-700 text-lg leading-relaxed mb-3">
                    {currentQuestion.question}
                  </p>
                  <p className="text-sm text-gray-600">
                    {currentQuestion.description}
                  </p>
                </div>
              </div>
            </div>

            {/* Answer Options */}
            <RadioGroup 
              value={responses[currentQuestionIndex] === null ? "" : responses[currentQuestionIndex] ? "1" : "0"}
              onValueChange={handleAnswerChange}
              className="space-y-3 mb-8"
            >
              <div className="flex items-center p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
                <RadioGroupItem value="1" id="yes" className="w-5 h-5" />
                <Label htmlFor="yes" className="flex-1 ml-4 cursor-pointer">
                  <div className="font-medium text-gray-900">Yes</div>
                  <div className="text-sm text-gray-600">The criteria is met and implemented properly</div>
                </Label>
                <CheckCircle className="text-success text-xl" />
              </div>

              <div className="flex items-center p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
                <RadioGroupItem value="0" id="no" className="w-5 h-5" />
                <Label htmlFor="no" className="flex-1 ml-4 cursor-pointer">
                  <div className="font-medium text-gray-900">No</div>
                  <div className="text-sm text-gray-600">The criteria is not met or needs improvement</div>
                </Label>
                <XCircle className="text-destructive text-xl" />
              </div>
            </RadioGroup>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-6 border-t border-gray-200">
            <Button
              variant="ghost"
              onClick={handlePrevious}
              disabled={isFirstQuestion}
              className="flex items-center"
            >
              <ChevronLeft className="mr-2 h-4 w-4" />
              Previous
            </Button>

            <div className="text-center">
              <div className="text-sm text-gray-600 mb-2">Current Score</div>
              <div className="text-2xl font-bold text-primary">
                {getCurrentScore()}/20
              </div>
            </div>

            {!isLastQuestion ? (
              <Button
                onClick={handleNext}
                disabled={responses[currentQuestionIndex] === null}
                className="flex items-center"
              >
                Next Question
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            ) : selectedFrameworks.length > 0 && !showComplianceQuestions ? (
              <Button
                onClick={() => setShowComplianceQuestions(true)}
                disabled={!allQuestionsAnswered}
                className="flex items-center"
              >
                Continue to Compliance Questions
                <Shield className="ml-2 h-4 w-4" />
              </Button>
            ) : (
              <Button
                onClick={handleSubmit}
                disabled={!allQuestionsAnswered || !allComplianceQuestionsAnswered || submitEvaluation.isPending}
                className="flex items-center"
              >
                {submitEvaluation.isPending ? "Submitting..." : "Complete Evaluation"}
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Compliance Questions Section */}
      {showComplianceQuestions && selectedFrameworks.length > 0 && (
        <div className="space-y-6 mb-8">
          {selectedFrameworks.map((frameworkId) => {
            const framework = getFrameworkById(frameworkId);
            if (!framework) return null;

            return (
              <Card key={frameworkId} className="border-purple-200">
                <CardContent className="p-8">
                  <div className="flex items-center mb-6">
                    <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mr-4">
                      <Shield className="text-purple-600 w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{framework.name}</h3>
                      <p className="text-sm text-gray-600">{framework.description}</p>
                    </div>
                  </div>

                  <div className="space-y-6">
                    {framework.questions.map((question, questionIndex) => {
                      const response = complianceResponses[frameworkId]?.[questionIndex];
                      
                      return (
                        <div key={question.id} className="bg-purple-50 rounded-lg p-6">
                          <div className="flex items-start space-x-4 mb-4">
                            <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                              <span className="text-white text-sm font-medium">{questionIndex + 1}</span>
                            </div>
                            <div className="flex-1">
                              <h4 className="font-semibold text-gray-900 mb-2">
                                {question.category}
                              </h4>
                              <p className="text-gray-700 text-lg leading-relaxed mb-3">
                                {question.question}
                              </p>
                              <p className="text-sm text-gray-600">
                                {question.description}
                              </p>
                            </div>
                          </div>

                          <RadioGroup 
                            value={response === null ? "" : response ? "1" : "0"}
                            onValueChange={(value) => handleComplianceAnswerChange(frameworkId, questionIndex, value)}
                            className="space-y-3"
                          >
                            <div className="flex items-center p-4 bg-white rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                              <RadioGroupItem value="1" id={`${frameworkId}-${questionIndex}-yes`} className="w-5 h-5" />
                              <Label htmlFor={`${frameworkId}-${questionIndex}-yes`} className="flex-1 ml-4 cursor-pointer">
                                <div className="font-medium text-gray-900">Yes</div>
                                <div className="text-sm text-gray-600">Compliant with this requirement</div>
                              </Label>
                              <CheckCircle className="text-success text-xl" />
                            </div>

                            <div className="flex items-center p-4 bg-white rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                              <RadioGroupItem value="0" id={`${frameworkId}-${questionIndex}-no`} className="w-5 h-5" />
                              <Label htmlFor={`${frameworkId}-${questionIndex}-no`} className="flex-1 ml-4 cursor-pointer">
                                <div className="font-medium text-gray-900">No</div>
                                <div className="text-sm text-gray-600">Not compliant or needs improvement</div>
                              </Label>
                              <XCircle className="text-destructive text-xl" />
                            </div>
                          </RadioGroup>
                        </div>
                      );
                    })}
                  </div>

                  <div className="mt-6 pt-6 border-t border-gray-200">
                    <div className="text-center">
                      <div className="text-sm text-gray-600 mb-2">{framework.name} Progress</div>
                      <div className="text-2xl font-bold text-purple-600">
                        {complianceResponses[frameworkId]?.filter(r => r !== null).length || 0}/{framework.questions.length}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}

          {/* Compliance Submit Button */}
          <div className="text-center">
            <Button
              onClick={handleSubmit}
              disabled={!allQuestionsAnswered || !allComplianceQuestionsAnswered || submitEvaluation.isPending}
              size="lg"
              className="text-lg px-8 py-3"
            >
              {submitEvaluation.isPending ? "Submitting..." : "Complete Full Evaluation"}
              <Settings className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </div>
      )}

      {/* Question Overview */}
      <Card>
        <CardContent className="p-6">
          <h3 className="font-semibold text-gray-900 mb-4">Question Overview</h3>
          <div className="grid grid-cols-10 gap-2">
            {evaluationQuestions.map((_, index) => {
              const isAnswered = responses[index] !== null;
              const isCurrent = index === currentQuestionIndex;
              
              return (
                <button
                  key={index}
                  onClick={() => setCurrentQuestionIndex(index)}
                  className={`w-8 h-8 rounded-full text-xs flex items-center justify-center font-medium transition-colors ${
                    isCurrent 
                      ? "bg-primary text-white" 
                      : isAnswered 
                        ? "bg-success text-white" 
                        : "bg-gray-200 text-gray-400"
                  }`}
                >
                  {index + 1}
                </button>
              );
            })}
          </div>
          
          <div className="flex items-center justify-between mt-4 text-xs text-gray-600">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 rounded-full bg-primary" />
                <span>Current</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 rounded-full bg-success" />
                <span>Completed</span>
              </div>
              <div className="flex items-center space-x-1">
                <div className="w-3 h-3 rounded-full bg-gray-200" />
                <span>Remaining</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
