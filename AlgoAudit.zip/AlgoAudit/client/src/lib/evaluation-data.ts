import { Question } from "@shared/schema";

export const evaluationQuestions: Question[] = [
  // Data Evaluation (0-3)
  {
    id: 0,
    category: "Data Evaluation",
    categoryIndex: 0,
    question: "Is the training data representative of the target population and use cases?",
    description: "Evaluate whether the data used to train the algorithm adequately represents the diversity of scenarios and populations it will encounter in production.",
    recommendation: "Conduct demographic analysis of your training data and compare it to your target population. Implement stratified sampling techniques to ensure all user groups are adequately represented. Consider data augmentation or synthetic data generation for underrepresented groups. Document data collection methodology to identify potential gaps."
  },
  {
    id: 1,
    category: "Data Evaluation",
    categoryIndex: 0,
    question: "Are there sufficient quality controls in place for data collection and processing?",
    description: "Assess the processes and standards used to ensure data accuracy, completeness, and reliability throughout the collection and processing pipeline.",
    recommendation: "Establish data validation rules and automated quality checks at each stage of the pipeline. Implement data profiling tools to identify anomalies, implement version control for datasets, and create data lineage documentation. Set up monitoring alerts for data quality degradation and establish clear escalation procedures."
  },
  {
    id: 2,
    category: "Data Evaluation",
    categoryIndex: 0,
    question: "Is the data set sufficiently large and diverse to support reliable model training?",
    description: "Determine if the dataset size and diversity are adequate for the algorithm's intended complexity and scope of application.",
    recommendation: "Perform statistical power analysis to determine minimum sample sizes for reliable results. Expand data collection efforts to include more diverse scenarios and edge cases. Consider partnerships with other organizations for data sharing, implement active learning to identify valuable data points, and use techniques like cross-validation to maximize learning from available data."
  },
  {
    id: 3,
    category: "Data Evaluation",
    categoryIndex: 0,
    question: "Are there documented procedures for handling missing, inconsistent, or outlier data?",
    description: "Verify that clear protocols exist for identifying and managing data quality issues that could impact algorithm performance.",
    recommendation: "Create comprehensive data handling procedures including missing value imputation strategies, outlier detection algorithms, and data consistency validation rules. Implement automated data cleaning pipelines with human oversight for edge cases. Document all data preprocessing steps and maintain audit trails of data modifications."
  },

  // Bias and Fairness Testing (4-7)
  {
    id: 4,
    category: "Bias and Fairness Testing",
    categoryIndex: 1,
    question: "Has the algorithm been tested for disparate impact across different demographic groups?",
    description: "Assess whether the algorithm produces significantly different outcomes for different demographic groups that could indicate bias.",
    recommendation: "Implement systematic bias testing using statistical parity, equalized odds, and individual fairness metrics. Create test scenarios for all protected demographic groups. Use tools like AI Fairness 360 or Fairlearn for comprehensive bias analysis. Document differential outcomes and investigate root causes in data or model architecture."
  },
  {
    id: 5,
    category: "Bias and Fairness Testing",
    categoryIndex: 1,
    question: "Are there established metrics and thresholds for measuring algorithmic fairness?",
    description: "Verify that specific, measurable criteria have been defined to evaluate fairness and that appropriate thresholds have been set.",
    recommendation: "Define specific fairness metrics relevant to your use case (demographic parity, equal opportunity, counterfactual fairness). Establish quantitative thresholds based on industry standards and regulatory requirements. Create monitoring dashboards to track fairness metrics continuously. Involve domain experts and affected communities in setting appropriate thresholds."
  },
  {
    id: 6,
    category: "Bias and Fairness Testing",
    categoryIndex: 1,
    question: "Has bias testing been conducted using representative test datasets?",
    description: "Confirm that bias evaluation has been performed using datasets that accurately reflect the real-world populations the algorithm will serve.",
    recommendation: "Curate diverse test datasets that mirror your production environment demographics. Include edge cases and historically marginalized groups in testing scenarios. Validate that test data distributions match deployment conditions. Consider synthetic data generation to supplement underrepresented groups while maintaining privacy."
  },
  {
    id: 7,
    category: "Bias and Fairness Testing",
    categoryIndex: 1,
    question: "Are there documented mitigation strategies for identified biases?",
    description: "Ensure that specific plans and procedures exist to address any biases that have been identified during testing.",
    recommendation: "Develop comprehensive bias mitigation playbook including pre-processing (data balancing, feature selection), in-processing (fairness constraints, adversarial debiasing), and post-processing (threshold optimization, outcome adjustment) techniques. Create escalation procedures for bias incidents and establish regular bias audit cycles."
  },

  // Output and Performance Evaluation (8-11)
  {
    id: 8,
    category: "Output and Performance Evaluation",
    categoryIndex: 2,
    question: "Does the algorithm consistently produce reliable outputs under normal operating conditions?",
    description: "Evaluate whether the algorithm delivers consistent, expected results when operating within its designed parameters and use cases.",
    recommendation: "Implement comprehensive regression testing with automated test suites covering typical use cases. Establish baseline performance metrics and set up monitoring to detect output consistency degradation. Create reproducible testing environments and document expected behavior for all standard scenarios."
  },
  {
    id: 9,
    category: "Output and Performance Evaluation",
    categoryIndex: 2,
    question: "Has the algorithm been tested for robustness under edge cases and stress conditions?",
    description: "Assess whether the algorithm maintains acceptable performance when encountering unusual inputs, high load, or boundary conditions.",
    recommendation: "Design comprehensive stress testing scenarios including high-volume inputs, malformed data, boundary values, and unusual input combinations. Implement chaos engineering practices to test resilience. Create automated load testing and establish graceful degradation procedures for system overload situations."
  },
  {
    id: 10,
    category: "Output and Performance Evaluation",
    categoryIndex: 2,
    question: "Are performance metrics clearly defined and regularly monitored?",
    description: "Verify that specific, measurable performance indicators have been established and are consistently tracked over time.",
    recommendation: "Define SMART (Specific, Measurable, Achievable, Relevant, Time-bound) performance metrics aligned with business objectives. Implement real-time monitoring dashboards with alerting thresholds. Establish regular performance review cycles and create benchmarking against industry standards and competitor solutions."
  },
  {
    id: 11,
    category: "Output and Performance Evaluation",
    categoryIndex: 2,
    question: "Is there a systematic process for validating output accuracy and relevance?",
    description: "Confirm that structured methods exist to verify that algorithm outputs are both accurate and appropriate for their intended use.",
    recommendation: "Implement multi-layered validation including automated accuracy checks, human expert review processes, and user feedback collection. Create ground truth datasets for validation, establish confidence scoring for outputs, and implement A/B testing frameworks to measure real-world effectiveness."
  },

  // Transparency and Explainability (12-15)
  {
    id: 12,
    category: "Transparency and Explainability",
    categoryIndex: 3,
    question: "Can the algorithm's decision-making process be explained in understandable terms?",
    description: "Assess whether the algorithm's logic and decision pathways can be communicated clearly to stakeholders and users.",
    recommendation: "Implement explainable AI techniques like LIME, SHAP, or attention mechanisms. Create user-friendly explanations tailored to different audiences (technical team, business stakeholders, end users). Develop interactive dashboards showing decision factors and confidence levels for individual predictions."
  },
  {
    id: 13,
    category: "Transparency and Explainability",
    categoryIndex: 3,
    question: "Is comprehensive documentation available for the algorithm's design and implementation?",
    description: "Verify that detailed documentation exists covering the algorithm's architecture, assumptions, limitations, and implementation details.",
    recommendation: "Create comprehensive technical documentation including algorithm architecture diagrams, data flow charts, model card specifications, API documentation, and decision logic flowcharts. Maintain living documentation that updates automatically with code changes and includes examples of typical use cases."
  },
  {
    id: 14,
    category: "Transparency and Explainability",
    categoryIndex: 3,
    question: "Are the algorithm's limitations and potential failure modes clearly documented?",
    description: "Ensure that known constraints, edge cases, and potential points of failure have been identified and documented.",
    recommendation: "Conduct systematic failure mode analysis documenting all known limitations, edge cases, and potential failure scenarios. Create user-facing guidance on appropriate use cases and scenarios to avoid. Implement uncertainty quantification to flag low-confidence predictions and establish clear boundaries for algorithm applicability."
  },
  {
    id: 15,
    category: "Transparency and Explainability",
    categoryIndex: 3,
    question: "Is there a clear audit trail for algorithm changes and version control?",
    description: "Confirm that all modifications, updates, and versions of the algorithm are properly tracked and documented for accountability.",
    recommendation: "Implement comprehensive version control using Git with detailed commit messages, maintain change logs for all algorithm modifications, establish approval workflows for production changes, and create automated deployment pipelines with rollback capabilities. Document the business justification for all changes."
  },

  // Post-Deployment Monitoring & Risk Assessment (16-19)
  {
    id: 16,
    category: "Post-Deployment Monitoring & Risk Assessment",
    categoryIndex: 4,
    question: "Are there continuous monitoring systems in place to track algorithm performance?",
    description: "Verify that automated systems exist to continuously monitor the algorithm's performance and detect potential issues in real-time.",
    recommendation: "Deploy comprehensive monitoring infrastructure including performance metrics dashboards, automated alerting systems, data drift detection, model performance tracking, and real-time anomaly detection. Set up observability tools like DataDog, New Relic, or custom monitoring solutions with appropriate SLA thresholds."
  },
  {
    id: 17,
    category: "Post-Deployment Monitoring & Risk Assessment",
    categoryIndex: 4,
    question: "Is there a systematic process for identifying and responding to performance degradation?",
    description: "Assess whether clear procedures exist to detect when algorithm performance declines and to implement corrective actions.",
    recommendation: "Establish automated performance degradation detection using statistical process control methods, create escalation matrices for different severity levels, implement automatic rollback mechanisms for critical failures, and maintain incident response playbooks with clear roles and responsibilities for performance issues."
  },
  {
    id: 18,
    category: "Post-Deployment Monitoring & Risk Assessment",
    categoryIndex: 4,
    question: "Are potential risks to stakeholders regularly assessed and documented?",
    description: "Confirm that ongoing risk assessments are conducted to identify and document potential impacts on users, organizations, and society.",
    recommendation: "Conduct quarterly stakeholder risk assessments involving all affected parties, maintain living risk registers with impact and probability matrices, implement stakeholder feedback collection systems, and establish regular risk review meetings with cross-functional teams including legal, compliance, and ethics representatives."
  },
  {
    id: 19,
    category: "Post-Deployment Monitoring & Risk Assessment",
    categoryIndex: 4,
    question: "Is there a defined incident response plan for algorithm failures or unintended consequences?",
    description: "Ensure that clear protocols exist for responding to algorithm failures, errors, or unintended outcomes that could cause harm.",
    recommendation: "Develop comprehensive incident response procedures including immediate containment steps, escalation chains, communication templates for stakeholders, forensic analysis protocols, remediation strategies, and post-incident review processes. Practice incident response through regular tabletop exercises and simulations."
  }
];

export const categoryInfo = [
  {
    name: "Data Evaluation",
    icon: "database",
    description: "Assess data reliability and completeness",
    color: "blue"
  },
  {
    name: "Bias and Fairness Testing", 
    icon: "balance-scale",
    description: "Identify and mitigate potential biases",
    color: "green"
  },
  {
    name: "Output and Performance Evaluation",
    icon: "tachometer-alt", 
    description: "Evaluate consistency and resilience",
    color: "orange"
  },
  {
    name: "Transparency and Explainability",
    icon: "eye",
    description: "Ensure accountability and clarity", 
    color: "purple"
  },
  {
    name: "Post-Deployment Monitoring & Risk Assessment",
    icon: "shield-alt",
    description: "Monitor and mitigate ongoing risks",
    color: "red"
  }
];
