import { Question } from "@shared/schema";

export interface ComplianceFramework {
  id: string;
  name: string;
  description: string;
  industry: string;
  questions: Question[];
}

export const complianceFrameworks: ComplianceFramework[] = [
  {
    id: "soc2",
    name: "SOC 2",
    description: "Service Organization Control 2 - Security, availability, processing integrity, confidentiality, and privacy",
    industry: "Technology Services",
    questions: [
      {
        id: 100,
        category: "Security",
        categoryIndex: 0,
        question: "Are logical access controls implemented to restrict access to data and systems?",
        description: "Verify that appropriate user authentication, authorization, and access management controls are in place.",
        recommendation: "Implement multi-factor authentication (MFA), role-based access control (RBAC), regular access reviews, privileged access management (PAM), and automated user provisioning/deprovisioning. Establish identity governance framework with least privilege principles and regular access certifications."
      },
      {
        id: 101,
        category: "Security",
        categoryIndex: 0,
        question: "Is data encrypted both in transit and at rest?",
        description: "Ensure that sensitive data is protected through encryption during transmission and storage.",
        recommendation: "Deploy TLS 1.3 for data in transit, AES-256 encryption for data at rest, implement key management systems (KMS), use database encryption features, establish encryption key rotation policies, and ensure secure key storage with hardware security modules (HSMs) where appropriate."
      },
      {
        id: 102,
        category: "Availability",
        categoryIndex: 1,
        question: "Are system availability metrics monitored and maintained?",
        description: "Confirm that system uptime and performance are continuously monitored with defined SLAs.",
        recommendation: "Establish 99.9% uptime SLAs, implement redundant systems and failover mechanisms, deploy comprehensive monitoring with alerting, create disaster recovery plans, conduct regular backup testing, and maintain incident response procedures with clear escalation paths."
      },
      {
        id: 103,
        category: "Processing Integrity",
        categoryIndex: 2,
        question: "Are data processing activities validated for completeness and accuracy?",
        description: "Verify that data processing includes validation controls to ensure accuracy and completeness.",
        recommendation: "Implement automated data validation rules, checksum verification, transaction logging, reconciliation processes, error handling procedures, and audit trails. Establish data quality monitoring with automated alerts for anomalies and implement data lineage tracking."
      },
      {
        id: 104,
        category: "Confidentiality",
        categoryIndex: 3,
        question: "Are confidentiality agreements and data handling procedures in place?",
        description: "Ensure that confidential information is protected through appropriate policies and procedures.",
        recommendation: "Establish comprehensive data classification policies, implement confidentiality agreements for all personnel, create secure data handling procedures, deploy data loss prevention (DLP) tools, maintain confidential data inventories, and conduct regular confidentiality training."
      }
    ]
  },
  {
    id: "hipaa",
    name: "HIPAA",
    description: "Health Insurance Portability and Accountability Act - Healthcare data privacy and security",
    industry: "Healthcare",
    questions: [
      {
        id: 200,
        category: "Administrative Safeguards",
        categoryIndex: 0,
        question: "Is there a designated HIPAA Security Officer responsible for PHI security?",
        description: "Verify that a qualified individual has been assigned responsibility for PHI security policies.",
        recommendation: "Formally appoint a qualified HIPAA Security Officer with documented responsibilities, provide specialized HIPAA training, establish clear reporting structures, create written job descriptions including security duties, and ensure adequate resources and authority to implement security measures effectively."
      },
      {
        id: 201,
        category: "Physical Safeguards",
        categoryIndex: 1,
        question: "Are physical access controls implemented to protect PHI storage areas?",
        description: "Ensure that physical locations containing PHI are secured from unauthorized access.",
        recommendation: "Install access control systems (key cards, biometrics), implement visitor management procedures, establish clean desk policies, secure equipment with locks, install security cameras for monitoring, and maintain physical access logs with regular reviews of entry permissions."
      },
      {
        id: 202,
        category: "Technical Safeguards",
        categoryIndex: 2,
        question: "Are audit logs maintained for all PHI access and modifications?",
        description: "Confirm that all access to and changes of PHI are logged and regularly reviewed.",
        recommendation: "Deploy comprehensive audit logging systems capturing all PHI access events, implement centralized log management with tamper-evident storage, establish automated log analysis for suspicious activities, conduct regular audit log reviews, and maintain long-term log retention as required by regulations."
      },
      {
        id: 203,
        category: "Data Integrity",
        categoryIndex: 3,
        question: "Are controls in place to prevent unauthorized alteration of PHI?",
        description: "Verify that PHI cannot be improperly altered or destroyed without proper authorization.",
        recommendation: "Implement electronic signature systems, deploy version control for PHI modifications, establish data validation rules, use database triggers for change tracking, implement role-based permissions for data modification, and maintain backup systems with integrity verification."
      },
      {
        id: 204,
        category: "Transmission Security",
        categoryIndex: 4,
        question: "Is PHI protected during electronic transmission?",
        description: "Ensure that PHI is encrypted and secured when transmitted over networks.",
        recommendation: "Deploy end-to-end encryption for all PHI transmissions, use secure communication protocols (TLS 1.3, SFTP), implement VPN access for remote workers, establish secure email gateways, validate encryption strength regularly, and maintain transmission security documentation."
      }
    ]
  },
  {
    id: "hitrust",
    name: "HITRUST CSF",
    description: "Health Information Trust Alliance Common Security Framework",
    industry: "Healthcare",
    questions: [
      {
        id: 300,
        category: "Information Security Management",
        categoryIndex: 0,
        question: "Is there a comprehensive information security management system in place?",
        description: "Verify that formal information security policies and procedures are established and maintained."
      },
      {
        id: 301,
        category: "Access Control",
        categoryIndex: 1,
        question: "Are privileged access rights regularly reviewed and updated?",
        description: "Ensure that administrative and privileged access is properly managed and audited."
      },
      {
        id: 302,
        category: "Risk Assessment",
        categoryIndex: 2,
        question: "Are regular risk assessments conducted for information assets?",
        description: "Confirm that systematic risk assessments identify and evaluate security threats."
      },
      {
        id: 303,
        category: "Incident Management",
        categoryIndex: 3,
        question: "Is there a documented incident response plan for security breaches?",
        description: "Verify that procedures exist for detecting, responding to, and recovering from security incidents."
      }
    ]
  },
  {
    id: "pci_dss",
    name: "PCI DSS",
    description: "Payment Card Industry Data Security Standard - Credit card data protection",
    industry: "Financial Services",
    questions: [
      {
        id: 400,
        category: "Network Security",
        categoryIndex: 0,
        question: "Are firewalls and network security controls properly configured?",
        description: "Verify that network access to cardholder data is restricted and monitored."
      },
      {
        id: 401,
        category: "Data Protection",
        categoryIndex: 1,
        question: "Is cardholder data encrypted using strong cryptography?",
        description: "Ensure that stored cardholder data is protected with appropriate encryption methods."
      },
      {
        id: 402,
        category: "Vulnerability Management",
        categoryIndex: 2,
        question: "Are systems regularly scanned for vulnerabilities and patched?",
        description: "Confirm that vulnerability management processes identify and remediate security weaknesses."
      },
      {
        id: 403,
        category: "Access Control",
        categoryIndex: 3,
        question: "Is access to cardholder data restricted on a need-to-know basis?",
        description: "Verify that access to sensitive payment data is limited to authorized personnel only."
      },
      {
        id: 404,
        category: "Monitoring",
        categoryIndex: 4,
        question: "Are all access attempts to cardholder data logged and monitored?",
        description: "Ensure that comprehensive logging and monitoring covers all access to payment data."
      }
    ]
  },
  {
    id: "nist",
    name: "NIST Cybersecurity Framework",
    description: "National Institute of Standards and Technology Cybersecurity Framework",
    industry: "Government/General",
    questions: [
      {
        id: 500,
        category: "Identify",
        categoryIndex: 0,
        question: "Are organizational assets and data flows documented and understood?",
        description: "Verify that the organization maintains an inventory of systems, data, and cybersecurity risks."
      },
      {
        id: 501,
        category: "Protect",
        categoryIndex: 1,
        question: "Are appropriate safeguards implemented to protect critical assets?",
        description: "Ensure that protective measures are in place for systems, data, and personnel."
      },
      {
        id: 502,
        category: "Detect",
        categoryIndex: 2,
        question: "Are detection processes in place to identify cybersecurity events?",
        description: "Confirm that monitoring and detection capabilities can identify potential security incidents."
      },
      {
        id: 503,
        category: "Respond",
        categoryIndex: 3,
        question: "Is there a documented incident response plan and communication strategy?",
        description: "Verify that response procedures are established for cybersecurity incidents."
      },
      {
        id: 504,
        category: "Recover",
        categoryIndex: 4,
        question: "Are recovery plans tested and maintained for business continuity?",
        description: "Ensure that recovery procedures can restore systems and data after cybersecurity incidents."
      }
    ]
  },
  {
    id: "gdpr",
    name: "GDPR",
    description: "General Data Protection Regulation - European Union data protection law",
    industry: "General",
    questions: [
      {
        id: 600,
        category: "Lawful Basis",
        categoryIndex: 0,
        question: "Is there a clear lawful basis for processing personal data?",
        description: "Verify that data processing has a legitimate legal basis under GDPR Article 6."
      },
      {
        id: 601,
        category: "Data Minimization",
        categoryIndex: 1,
        question: "Is personal data collection limited to what is necessary for the stated purpose?",
        description: "Ensure that only required personal data is collected and processed."
      },
      {
        id: 602,
        category: "Individual Rights",
        categoryIndex: 2,
        question: "Are procedures in place to handle data subject rights requests?",
        description: "Confirm that individuals can exercise their rights to access, rectify, and delete personal data."
      },
      {
        id: 603,
        category: "Data Protection by Design",
        categoryIndex: 3,
        question: "Are privacy considerations integrated into system design and development?",
        description: "Verify that privacy and data protection are considered from the beginning of system design."
      },
      {
        id: 604,
        category: "Breach Notification",
        categoryIndex: 4,
        question: "Are processes in place for detecting and reporting data breaches within 72 hours?",
        description: "Ensure that data breach detection and notification procedures meet GDPR requirements."
      }
    ]
  },
  {
    id: "iso_27001",
    name: "ISO 27001",
    description: "International standard for information security management systems",
    industry: "General",
    questions: [
      {
        id: 700,
        category: "Information Security Policy",
        categoryIndex: 0,
        question: "Is there a comprehensive information security policy approved by management?",
        description: "Verify that formal security policies are established and regularly reviewed."
      },
      {
        id: 701,
        category: "Risk Management",
        categoryIndex: 1,
        question: "Is a systematic risk assessment process implemented and maintained?",
        description: "Ensure that information security risks are regularly identified and assessed."
      },
      {
        id: 702,
        category: "Asset Management",
        categoryIndex: 2,
        question: "Are information assets identified, classified, and properly protected?",
        description: "Confirm that all information assets are inventoried and protected according to their classification."
      },
      {
        id: 703,
        category: "Incident Management",
        categoryIndex: 3,
        question: "Are security incidents properly managed and lessons learned documented?",
        description: "Verify that security incident response includes analysis and improvement processes."
      }
    ]
  }
];

export const industries = [
  "Healthcare",
  "Financial Services", 
  "Technology Services",
  "Government",
  "Education",
  "Retail",
  "Manufacturing",
  "Other"
];

export function getFrameworksByIndustry(industry: string): ComplianceFramework[] {
  return complianceFrameworks.filter(framework => 
    framework.industry === industry || framework.industry === "General"
  );
}

export function getFrameworkById(id: string): ComplianceFramework | undefined {
  return complianceFrameworks.find(framework => framework.id === id);
}