import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertEvaluationSchema, evaluationResponseSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Calculate SDEV_520 score
  function calculateSDEV520Score(responses: boolean[]) {
    if (responses.length !== 20) {
      throw new Error("Expected exactly 20 responses (one per question).");
    }
    
    const totalScore = responses.reduce((sum, response) => sum + (response ? 1 : 0), 0);
    
    let riskCategory: string;
    if (totalScore >= 16) {
      riskCategory = "Low Risk (Excellent)";
    } else if (totalScore >= 10) {
      riskCategory = "Moderate Risk (Needs Improvement)";
    } else if (totalScore >= 5) {
      riskCategory = "High Risk (Significant Issues)";
    } else {
      riskCategory = "Critical Risk (Severe Problems)";
    }
    
    // Calculate category scores (4 questions per category)
    const categoryScores = {
      dataEvaluation: responses.slice(0, 4).reduce((sum, response) => sum + (response ? 1 : 0), 0),
      biasAndFairness: responses.slice(4, 8).reduce((sum, response) => sum + (response ? 1 : 0), 0),
      performance: responses.slice(8, 12).reduce((sum, response) => sum + (response ? 1 : 0), 0),
      transparency: responses.slice(12, 16).reduce((sum, response) => sum + (response ? 1 : 0), 0),
      riskAssessment: responses.slice(16, 20).reduce((sum, response) => sum + (response ? 1 : 0), 0),
    };
    
    return { totalScore, riskCategory, categoryScores };
  }

  // Calculate compliance score
  function calculateComplianceScore(complianceResponses: Record<string, boolean[]>) {
    let totalQuestions = 0;
    let totalCorrect = 0;
    const frameworkScores: Record<string, number> = {};
    
    for (const [framework, responses] of Object.entries(complianceResponses)) {
      const correct = responses.reduce((sum, response) => sum + (response ? 1 : 0), 0);
      frameworkScores[framework] = correct;
      totalQuestions += responses.length;
      totalCorrect += correct;
    }
    
    return {
      complianceScore: totalQuestions > 0 ? Math.round((totalCorrect / totalQuestions) * 100) : 0,
      complianceBreakdown: frameworkScores,
    };
  }

  // Submit evaluation
  app.post("/api/evaluations", async (req, res) => {
    try {
      const data = evaluationResponseSchema.parse(req.body);
      
      const { totalScore, riskCategory, categoryScores } = calculateSDEV520Score(data.responses);
      const { complianceScore, complianceBreakdown } = calculateComplianceScore(data.complianceResponses || {});
      
      const evaluationData = insertEvaluationSchema.parse({
        algorithmName: data.algorithmName,
        evaluatorName: data.evaluatorName,
        industry: data.industry,
        complianceFrameworks: data.complianceFrameworks,
        responses: data.responses,
        complianceResponses: data.complianceResponses,
        totalScore,
        complianceScore,
        riskCategory,
        categoryScores,
        complianceBreakdown,
      });
      
      const evaluation = await storage.createEvaluation(evaluationData);
      res.json(evaluation);
    } catch (error) {
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // Get evaluation by ID
  app.get("/api/evaluations/:id", async (req, res) => {
    try {
      const evaluation = await storage.getEvaluation(req.params.id);
      if (!evaluation) {
        return res.status(404).json({ message: "Evaluation not found" });
      }
      res.json(evaluation);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get all evaluations
  app.get("/api/evaluations", async (req, res) => {
    try {
      const evaluations = await storage.getEvaluations();
      res.json(evaluations);
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
