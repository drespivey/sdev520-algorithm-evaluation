# SDEV520 Algorithm Evaluation Tool

A comprehensive web application for evaluating AI algorithms using the SDEV520 framework with expanded compliance assessment capabilities for major industry standards.

## 🚀 Features

### Core SDEV520 Evaluation
- **20 structured questions** across 5 critical categories
- **Automated scoring** with risk classification (Low, Moderate, High, Critical)
- **Category breakdown** for targeted improvement insights
- **Real-time progress tracking** during evaluation

### Industry Compliance Assessment
- **7 major compliance frameworks**: SOC 2, HIPAA, HITRUST, PCI DSS, NIST CSF, GDPR, ISO 27001
- **8 industry types** with dynamic framework filtering
- **Compliance scoring** with detailed breakdowns
- **Multi-stage evaluation** process

### Comprehensive Reporting
- **Full detailed reports** with executive summaries and recommendations
- **CSV data export** for analysis and integration
- **Print-friendly formatting** for documentation
- **Professional audit trail** capabilities

### Technical Architecture
- **React 18** with TypeScript for type-safe development
- **PostgreSQL** database with Neon serverless platform
- **Drizzle ORM** for type-safe database operations
- **Tailwind CSS** with shadcn/ui components
- **Express.js** REST API backend

## 📋 Evaluation Categories

1. **Data Evaluation** - Assess data reliability, completeness, and quality
2. **Bias and Fairness Testing** - Identify and mitigate algorithmic biases
3. **Performance Evaluation** - Measure consistency, resilience, and reliability
4. **Transparency and Explainability** - Ensure accountability and interpretability
5. **Risk Assessment** - Monitor and manage ongoing operational risks

## 🏢 Supported Compliance Frameworks

| Framework | Industry Focus | Questions |
|-----------|----------------|-----------|
| **SOC 2** | Security & Availability | 12 questions |
| **HIPAA** | Healthcare Privacy | 15 questions |
| **HITRUST** | Healthcare Security | 18 questions |
| **PCI DSS** | Payment Security | 14 questions |
| **NIST CSF** | Cybersecurity | 16 questions |
| **GDPR** | Data Protection | 13 questions |
| **ISO 27001** | Information Security | 17 questions |

## 🎯 Scoring System

- **Total Score Range**: 0-20 points (binary yes/no responses)
- **Risk Categories**:
  - 16-20: Low Risk (Excellent)
  - 10-15: Moderate Risk (Needs Improvement)
  - 5-9: High Risk (Significant Issues)
  - 0-4: Critical Risk (Severe Problems)

## 🛠️ Installation & Setup

### Prerequisites
- Node.js 18+ 
- PostgreSQL database
- npm or yarn package manager

### Local Development
```bash
# Clone the repository
git clone <your-repo-url>
cd sdev520-evaluation-tool

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your database credentials

# Push database schema
npm run db:push

# Start development server
npm run dev
```

### Environment Variables
```env
DATABASE_URL=your_postgresql_connection_string
PGHOST=your_db_host
PGPORT=5432
PGUSER=your_db_user
PGPASSWORD=your_db_password
PGDATABASE=your_db_name
```

## 📁 Project Structure

```
├── client/src/           # React frontend application
│   ├── components/       # Reusable UI components
│   ├── pages/           # Page components (Home, Evaluation, Results)
│   ├── lib/             # Utilities and data definitions
│   └── hooks/           # Custom React hooks
├── server/              # Express.js backend
│   ├── index.ts         # Server entry point
│   ├── routes.ts        # API route definitions
│   ├── storage.ts       # Database storage layer
│   └── db.ts           # Database connection setup
├── shared/              # Shared TypeScript types
│   └── schema.ts        # Drizzle database schema
└── attached_assets/     # Reference documentation
```

## 🚀 Deployment

### Replit Deployment (Recommended)
1. Fork this project in Replit
2. Set up environment variables in Replit Secrets
3. Click "Deploy" to publish your application

### Traditional Hosting
```bash
# Build the application
npm run build

# Start production server
npm start
```

## 📊 Usage Guide

### Starting an Evaluation
1. Navigate to the application homepage
2. Click "Start Algorithm Evaluation"
3. Fill in algorithm details and select industry
4. Choose relevant compliance frameworks
5. Answer 20 core SDEV_520 questions
6. Complete optional compliance assessments
7. Review results and download reports

### Exporting Reports
- **Full Report**: Comprehensive text document with analysis
- **CSV Export**: Structured data for spreadsheet analysis  
- **Print Format**: Professional formatting for physical documentation

## 🏗️ Technical Implementation

### Database Schema
- **evaluations**: Core evaluation records with scores and metadata
- **Drizzle ORM**: Type-safe database operations
- **PostgreSQL**: Reliable data persistence with ACID compliance

### Frontend Architecture
- **React Query**: Server state management and caching
- **React Hook Form**: Form validation and handling
- **Wouter**: Lightweight client-side routing
- **Tailwind CSS**: Utility-first styling approach

### Backend Services
- **Express.js**: RESTful API server
- **TypeScript**: Type-safe server-side development
- **Zod**: Runtime type validation
- **Centralized error handling**: Consistent API responses

## 🔒 Security & Compliance

- Database encryption at rest and in transit
- Input validation and sanitization
- Session management capabilities (ready for implementation)
- Audit trail functionality for compliance reporting
- Industry-standard security practices

## 📈 Analytics & Insights

- Historical evaluation tracking
- Trend analysis capabilities
- Category performance metrics
- Compliance gap identification
- Improvement recommendations

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🏆 Credits

Based on the Spivey GCEF Algorithm Evaluation Checklist and SDEV520 Score framework for comprehensive AI algorithm assessment.

---

**Built with** ❤️ **for responsible AI development and deployment**