# SDEV520 Algorithm Evaluation Tool

## Overview
This is a comprehensive web application for evaluating algorithms using the SDEV520 framework with expanded compliance assessment capabilities. It provides a structured assessment tool with 20 core questions across 5 categories, plus optional industry-specific compliance questions for major frameworks like SOC 2, HIPAA, HITRUST, PCI DSS, NIST, GDPR, and ISO 27001. The application features a React frontend with a Node.js/Express backend and uses PostgreSQL for data persistence.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Form Handling**: React Hook Form with Zod validation
- **UI Components**: Radix UI primitives with shadcn/ui styling system
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **Build Tool**: Vite for development and bundling

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Pattern**: RESTful API design
- **Middleware**: Built-in Express middleware for JSON parsing and logging
- **Error Handling**: Centralized error handling middleware

### Data Storage Solutions
- **Database**: PostgreSQL with Neon Database serverless platform
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Fallback Storage**: In-memory storage implementation for development/testing

## Key Components

### Evaluation System
- **Core SDEV520**: 20 predefined questions across 5 categories (4 questions each)
- **Categories**: Data Evaluation, Bias and Fairness Testing, Performance, Transparency, Risk Assessment
- **Compliance Frameworks**: Optional industry-specific questions for SOC 2, HIPAA, HITRUST, PCI DSS, NIST, GDPR, ISO 27001
- **Industry Selection**: Dynamic framework filtering based on selected industry
- **Scoring Logic**: Boolean responses with weighted category scoring, overall risk assessment, and compliance percentage
- **Progress Tracking**: Visual progress indicators and category completion status
- **Multi-Stage Process**: Core evaluation followed by optional compliance assessment

### UI Components
- **Navigation**: Header component with brand identity and route navigation
- **Forms**: Multi-step evaluation form with validation and progress tracking
- **Results Display**: Score visualization with category breakdowns, risk categorization, and comprehensive report export (TXT, CSV, Print)
- **Responsive Design**: Mobile-first approach with Tailwind responsive utilities

### Data Models
- **Evaluation Schema**: Stores algorithm name, evaluator name, responses array, calculated scores, and timestamps
- **Question Schema**: Structured question data with categories and descriptions
- **Response Validation**: Zod schemas for runtime type checking and validation

## Data Flow

### Evaluation Process
1. User fills out algorithm and evaluator information
2. User progresses through 20 questions with yes/no responses
3. Frontend validates all responses before submission
4. Backend calculates total score and category scores
5. Risk category determined based on total score thresholds
6. Results stored in database and returned to frontend
7. User redirected to results page with detailed breakdown

### Score Calculation
- **Total Score**: Sum of all positive responses (0-20)
- **Risk Categories**: 
  - 16-20: Low Risk (Excellent)
  - 10-15: Moderate Risk (Needs Improvement)
  - 5-9: High Risk (Significant Issues)
  - 0-4: Critical Risk (Severe Problems)
- **Category Scores**: Individual scoring per evaluation category (0-4 each)

## External Dependencies

### Core Libraries
- **Frontend**: React, TypeScript, Wouter, TanStack Query, React Hook Form, Zod
- **UI**: Radix UI, shadcn/ui, Tailwind CSS, Lucide React icons
- **Backend**: Express.js, TypeScript, tsx for development
- **Database**: Drizzle ORM, Neon Database serverless, PostgreSQL

### Development Tools
- **Build**: Vite, esbuild for production builds
- **Development**: Replit-specific plugins for enhanced development experience
- **Type Checking**: TypeScript compiler with strict configuration

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds React application to `dist/public`
- **Backend**: esbuild bundles Express server to `dist/index.js`
- **Database**: Drizzle migrations applied via `db:push` command

### Environment Configuration
- **Development**: Uses tsx for TypeScript execution and Vite dev server
- **Production**: Serves built frontend assets through Express static middleware
- **Database**: Requires `DATABASE_URL` environment variable for PostgreSQL connection

### Hosting Considerations
- **Static Assets**: Frontend built files served by Express in production
- **API Routes**: Express handles all `/api/*` endpoints
- **Database**: Neon Database provides serverless PostgreSQL with connection pooling
- **Sessions**: Ready for session management with connect-pg-simple (imported but not yet implemented)

### Scalability Features
- **Database**: Drizzle ORM provides type-safe queries with good performance
- **Frontend**: React Query handles caching and background updates
- **API**: Stateless design allows for horizontal scaling
- **Storage**: Dual storage implementation allows switching between in-memory and persistent storage